// Scroll animation for work items
document.addEventListener('scroll', function () {
    const workItems = document.querySelectorAll('.work-item');
    const triggerBottom = window.innerHeight * 0.8;

    workItems.forEach(item => {
        const itemTop = item.getBoundingClientRect().top;

        if (itemTop < triggerBottom) {
            item.classList.add('scrolled');
        } else {
            item.classList.remove('scrolled');
        }
    });
});
